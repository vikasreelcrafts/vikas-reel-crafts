import Head from 'next/head'
import Image from 'next/image'
import { Mail, Film, Users, Phone, Instagram } from 'lucide-react'

export default function Home() {
  return (
    <div className="min-h-screen bg-black text-white p-6 space-y-10">
      <Head>
        <title>Vikas Reel Crafts</title>
      </Head>

      <header className="text-center space-y-2">
        <h1 className="text-5xl font-bold text-yellow-400">Vikas Reel Crafts</h1>
        <p className="text-lg text-gray-300">A Visionary Film Production Company</p>
      </header>

      <section className="grid md:grid-cols-2 gap-6">
        <div className="bg-gray-900 border border-gray-700 p-6 rounded-xl">
          <Film className="w-8 h-8 text-yellow-400 mb-4" />
          <h2 className="text-2xl font-semibold mb-2">About Us</h2>
          <p className="text-gray-300">
            Vikas Reel Crafts is a passionate film production company dedicated to crafting memorable cinema. We bring stories to life with heart, vision, and creativity.
          </p>
        </div>

        <div className="bg-gray-900 border border-gray-700 p-6 rounded-xl">
          <Users className="w-8 h-8 text-yellow-400 mb-4" />
          <h2 className="text-2xl font-semibold mb-2">Team</h2>
          <ul className="text-gray-300 space-y-1">
            <li><strong>CEO & Director:</strong> Praveen Gattu</li>
            <li><strong>Producers:</strong> Veera Lakshmaiah & Shiva</li>
          </ul>
        </div>
      </section>

      <section className="text-center space-y-4">
        <h2 className="text-2xl font-semibold text-yellow-400">Gallery</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          <Image src="/upscalemedia-transformed.png" alt="Sadaajapa Poster" width={300} height={450} className="rounded-xl mx-auto" />
          <Image src="/स्वर्णिम फिल्म निर्माण प्रतीक.png" alt="Golden Film Logo" width={300} height={300} className="rounded-xl mx-auto" />
          <Image src="/Vikas Reel Crafts Stone Sculpture.png" alt="Stone Sculpture Logo 1" width={300} height={300} className="rounded-xl mx-auto" />
          <Image src="/Sculptor and Film Reel Emblem.png" alt="Stone Sculpture Logo 2" width={300} height={300} className="rounded-xl mx-auto" />
        </div>
      </section>

      <section className="text-center space-y-4">
        <h2 className="text-2xl font-semibold text-yellow-400">Contact Us</h2>
        <p className="text-gray-300">For collaborations and inquiries:</p>
        <div className="flex flex-col items-center gap-2 text-gray-200">
          <p className="flex items-center gap-2"><Mail className="w-5 h-5" /> vikasreelcrafts@gmail.com</p>
          <p className="flex items-center gap-2"><Phone className="w-5 h-5" /> +91 93907 03773</p>
          <p className="flex items-center gap-2"><Phone className="w-5 h-5" /> +91 40 3189 3518 (Landline)</p>
          <p className="flex items-center gap-2"><Instagram className="w-5 h-5" /> @vikasreelcrafts</p>
        </div>
      </section>

      <footer className="text-center text-sm text-gray-500 pt-10">
        © {new Date().getFullYear()} Vikas Reel Crafts. All rights reserved.
      </footer>
    </div>
  )
}